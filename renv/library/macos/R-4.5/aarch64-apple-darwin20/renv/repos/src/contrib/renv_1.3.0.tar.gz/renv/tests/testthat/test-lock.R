
test_that("locks can be acquired, released", {

  skip_on_cran()

  renv_scope_options(renv.config.locking.enabled = TRUE)
  path <- renv_lock_path(renv_scope_tempfile())

  renv_lock_acquire(path)
  expect_true(file.exists(path))

  renv_lock_release(path)
  expect_false(file.exists(path))

})

test_that("scoped locks are released appropriately", {

  skip_on_cran()

  renv_scope_options(renv.config.locking.enabled = TRUE)
  path <- renv_lock_path(renv_scope_tempfile())

  local({
    renv_scope_lock(path)
    expect_true(file.exists(path))
  })

  expect_false(file.exists(path))

})

test_that("we can recursively acquire locks", {

  skip_on_cran()

  renv_scope_options(renv.config.locking.enabled = TRUE)
  path <- renv_lock_path(renv_scope_tempfile())

  local({

    renv_scope_lock(path)
    expect_true(file.exists(path))

    local({
      renv_scope_lock(path)
      expect_true(file.exists(path))
    })

    expect_true(file.exists(path))

  })

  expect_false(file.exists(path))

})

test_that("other processes cannot lock our owned locks", {

  skip_on_cran()

  skip_if(
    is.null(formals(system2)[["timeout"]]),
    "system2() lacks the timeout argument"
  )

  renv_scope_options(renv.config.locking.enabled = TRUE)
  path <- renv_lock_path(renv_scope_tempfile())

  renv_lock_acquire(path)

  script <- renv_test_code(
    {
      preamble
      print(renv:::renv_lock_acquire(path))
    },
    list(preamble = renv_tests_child_preamble(), path = path)
  )

  args <- c("--vanilla", "-s", "-f", shQuote(script))
  output <- suppressWarnings(
    system2(R(), args, stdout = FALSE, stderr = FALSE, timeout = 5L)
  )

  expect_equal(output, 124L)

})

test_that("lock acquisition backs off, and remains interruptible", {

  skip_on_cran()

  skip_if(
    is.null(formals(system2)[["timeout"]]),
    "system2() lacks the timeout argument"
  )

  # simulate a lock held by another process, which we'll never manage to acquire
  path <- renv_lock_path(renv_scope_tempfile())
  dir.create(path)

  result <- renv_scope_tempfile(fileext = ".rds")
  limit <- 2
  script <- renv_test_code(
    {
      preamble
      options(renv.config.locking.enabled = TRUE)
      options(renv.lock.timeout = 1e6)
      timing <- system.time(
        tryCatch({
          setTimeLimit(elapsed = limit, transient = TRUE)
          renv:::renv_lock_acquire(path)
        }, error = function(cnd) NULL)
      )
      setTimeLimit()
      saveRDS(timing, result)
    },
    list(
      preamble = renv_tests_child_preamble(),
      path     = path,
      limit    = limit,
      result   = result
    )
  )

  args <- c("--vanilla", "-s", "-f", shQuote(script))
  status <- suppressWarnings(
    system2(R(), args, stdout = FALSE, stderr = FALSE, timeout = 10L)
  )

  expect_equal(status, 0L)
  expect_true(file.exists(result))
  if (!file.exists(result))
    return()

  timing <- readRDS(result)

  # the loop has to sleep between attempts, so it should use almost no CPU, and
  # it has to let setTimeLimit()'s condition through rather than treating it as
  # one more reason to retry. previously it did neither. (#2358)
  cpu <- timing[["user.self"]] + timing[["sys.self"]]
  expect_lt(cpu, limit / 4)
  expect_lt(timing[["elapsed"]], limit * 5)

})

test_that("an unremovable lock fails rather than hanging", {

  skip_on_cran()
  skip_on_os("windows")

  skip_if(
    is.null(formals(system2)[["timeout"]]),
    "system2() lacks the timeout argument"
  )

  # root ignores the directory permissions we rely on here
  skip_if(
    identical(Sys.info()[["effective_user"]], "root"),
    "running as root"
  )

  renv_scope_options(renv.config.locking.enabled = TRUE)

  parent <- renv_scope_tempfile("renv-lock-parent-")
  ensure_directory(parent)

  # leave a stale lock in a read-only parent, so it cannot be removed
  path <- file.path(parent, "lock")
  dir.create(path)
  Sys.chmod(parent, mode = "0555")
  defer(Sys.chmod(parent, mode = "0755"))

  result <- renv_scope_tempfile(fileext = ".rds")
  script <- renv_test_code(
    {
      preamble
      options(renv.config.locking.enabled = TRUE)
      options(renv.lock.timeout = -1L)
      cnd <- tryCatch(
        renv:::renv_lock_acquire(path),
        renv_error_lock_unwritable = function(cnd) cnd
      )
      saveRDS(cnd, result)
    },
    list(preamble = renv_tests_child_preamble(), path = path, result = result)
  )

  args <- c("--vanilla", "-s", "-f", shQuote(script))
  status <- suppressWarnings(
    system2(R(), args, stdout = FALSE, stderr = FALSE, timeout = 15L)
  )

  expect_equal(status, 0L)
  expect_true(file.exists(result))
  if (!file.exists(result))
    return()

  cnd <- readRDS(result)
  expect_s3_class(cnd, "renv_error_lock_unwritable")
  expect_length(cnd$meta$body, 2L)
  expect_true(file.exists(path))

})

test_that("transient writability failures are retried", {

  skip_on_cran()

  path <- renv_lock_path(renv_scope_tempfile())
  attempts <- 0L
  probes <- 0L

  local_mocked_bindings(
    renv_lock_acquire_impl = function(path) {
      attempts <<- attempts + 1L
      if (attempts <= 9L)
        return(list(acquired = FALSE, reason = "transient", blocked = FALSE))
      dir.create(path)
      list(acquired = TRUE, reason = NULL, blocked = FALSE)
    },
    renv_lock_writable = function(path) {
      probes <<- probes + 1L
      probes > 1L
    }
  )

  expect_true(renv_lock_acquire(path))
  expect_equal(probes, 2L)
  renv_lock_release(path)

})

test_that("locks are released on process exit", {

  skip_on_cran()

  renv_scope_options(renv.config.locking.enabled = TRUE)
  path <- renv_lock_path(renv_scope_tempfile())

  code <- expr({
    renv_lock_acquire(!!path)
    stopifnot(file.exists(!!path))
  })

  args <- c("--vanilla", "-s", "-e", shQuote(stringify(code)))
  status <- suppressWarnings(
    system2(R(), args, stdout = FALSE, stderr = FALSE, timeout = 5L)
  )

  expect_equal(status, 1L)
  expect_false(file.exists(path))

})

test_that("we can refresh locks", {

  skip_on_cran()

  # create a file
  path <- renv_scope_tempfile("renv-lock-")
  file.create(path)

  # get current info
  old <- file.info(path, extra_cols = FALSE)

  # wait a bit
  Sys.sleep(2)

  # refresh the 'lock'
  renv_lock_refresh(path)
  new <- file.info(path, extra_cols = FALSE)

  # check for updated time
  expect_gt(new$mtime, old$mtime)

})


test_that("old locks are considered 'orphaned'", {

  skip_on_cran()

  renv_scope_options(renv.config.locking.enabled = TRUE)
  renv_scope_envvars(RENV_WATCHDOG_ENABLED = "FALSE")

  path <- renv_lock_path(renv_scope_tempfile())

  renv_scope_options(renv.lock.timeout = -1L)
  renv_lock_acquire(path)

  expect_true(renv_lock_orphaned(path))
  expect_true(file.exists(path))

  script <- renv_test_code({
    options(renv.config.locking.enabled = TRUE)
    options(renv.lock.timeout = -1L)
    stopifnot(renv:::renv_lock_acquire(path))
    stopifnot(file.exists(path))
  }, list(path = path))

  output <- renv_system_exec(
    command = R(),
    args    = c("--vanilla", "-s", "-f", shQuote(script)),
    action  = "checking for orphaned locks",
  )

  expect_false(file.exists(path))

})

test_that("a lock held by a live process is not orphaned, even if stale", {

  skip_on_cran()

  renv_scope_options(renv.config.locking.enabled = TRUE)
  renv_scope_envvars(RENV_WATCHDOG_ENABLED = "FALSE")
  renv_scope_options(renv.lock.timeout = 60L)

  path <- renv_lock_path(renv_scope_tempfile())
  renv_lock_acquire(path)

  # age the lock past the timeout; because it records this (live) process as
  # its owner, it should still not be considered orphaned
  Sys.setFileTime(path, Sys.time() - 3600)

  expect_false(renv_lock_orphaned(path))

  renv_lock_release(path)

})

test_that("a lock owned by a dead process falls back to the timeout", {

  skip_on_cran()

  renv_scope_options(renv.lock.timeout = 60L)

  path <- renv_lock_path(renv_scope_tempfile())
  dir.create(path)

  # find a pid that isn't currently in use
  deadpid <- 2147483646L
  while (renv_process_exists(deadpid))
    deadpid <- deadpid - 1L

  contents <- c(
    sprintf("Host: %s", renv_platform_nodename()),
    sprintf("Pid: %i", deadpid)
  )
  writeLines(contents, con = file.path(path, "owner"))

  # a dead owner does not make a fresh lock orphaned (we can't distinguish a
  # dead pid from one we lack permission to inspect), but a stale one is
  expect_false(renv_lock_orphaned(path))

  Sys.setFileTime(path, Sys.time() - 3600)
  expect_true(renv_lock_orphaned(path))

})

test_that("a lock owned by another host falls back to the timeout", {

  skip_on_cran()

  renv_scope_options(renv.lock.timeout = 60L)

  path <- renv_lock_path(renv_scope_tempfile())
  dir.create(path)

  contents <- c(
    "Host: some-other-host-that-is-not-us",
    sprintf("Pid: %i", Sys.getpid())
  )
  writeLines(contents, con = file.path(path, "owner"))

  # a fresh lock on another host is not orphaned ...
  expect_false(renv_lock_orphaned(path))

  # ... but a stale one is
  Sys.setFileTime(path, Sys.time() - 3600)
  expect_true(renv_lock_orphaned(path))

})

test_that("multiple renv processes successfully acquire, release locks", {

  skip_on_cran()
  skip_if(getRversion() < "4.0.0")
  skip_on_os("windows")
  skip_on_ci()

  renv_scope_options(renv.config.locking.enabled = TRUE)
  renv_scope_envvars(RENV_WATCHDOG_ENABLED = "FALSE")

  # initialize server
  server <- tryCatch(renv_socket_server(), error = skip)
  defer(close(server$socket))

  # initialize state
  n <- 100
  start <- tempfile("renv-start-")
  lockfile <- renv_lock_path(tempfile("renv-lock-"))

  # initialize shared file
  shared <- renv_scope_tempfile("renv-file-")
  writeLines("0", con = shared)

  # generate runner script
  script <- renv_test_code(

    code = {

      renv:::summon()

      # wait for start file
      wait_until(file.exists, start)

      # helper function
      increment <- function() {
        renv_lock_acquire(lockfile)
        stopifnot(file.exists(lockfile))
        number <- as.integer(readLines(shared))
        writeLines(as.character(number + 1L), con = shared)
        renv_lock_release(lockfile)
        number
      }

      # update shared file with lock acquired
      number <- catch(increment())
      if (inherits(number, "error"))
        number <- -1L

      # notify parent
      conn <- renv_socket_connect(port = port, open = "wb")
      defer(close(conn))
      serialize(number, connection = conn)

      # we're done
      invisible()

    },

    data = list(
      start = start,
      lockfile = lockfile,
      shared = shared,
      port = server$port
    )

  )

  # create start file
  file.create(start)

  # create a bunch of processes that try to update the shared file
  for (i in 1:n) {
    system2(
      command = R(),
      args = c("--vanilla", "-s", "-f", renv_shell_path(script)),
      wait = FALSE
    )
  }

  # wait for all the processes to communicate
  responses <- stack()
  for (i in 1:n) local({
    conn <- renv_socket_accept(server$socket, open = "rb", timeout = 60)
    defer(close(conn))
    responses$push(unserialize(conn))
  })

  # check that the count is correct
  contents <- readLines(shared)
  expect_equal(contents, as.character(n))

  # check that each process saw a unique value
  numbers <- unlist(responses$data())
  expect_equal(sort(numbers), 0:(n - 1))

})
